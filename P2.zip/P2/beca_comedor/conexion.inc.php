<?php 
date_default_timezone_set('America/La_Paz');
$con = mysqli_connect('localhost', 'inf324', '123456', 'bdcomedor');





