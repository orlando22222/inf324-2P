CREATE TABLE FlujoProceso(
    flujo VARCHAR(3),
    proceso VARCHAR(3),
    proceso_sig VARCHAR(3),
    tipo VARCHAR(1),
    pantalla VARCHAR(30),
    rol VARCHAR(20)
);

CREATE TABLE FlujoProcesoCondicionante(
    flujo VARCHAR(3),
	proceso VARCHAR(3),
    proceso_si VARCHAR(3),
    proceso_no VARCHAR(3)
);

INSERT INTO FlujoProceso(flujo,proceso,proceso_sig,tipo,pantalla,rol) VALUES
('F1','P1','P2','I','PublicacionConvocatoria','direccion'),
('F1','P2','P3','P','RecolectarDocumentos','postulante'),
('F1','P3','P4','P','SolicitarRecord','postulante'),
('F1','P4','P5','P','ImprimirRecord','kardex'),
('F1','P5','P6','P','EnviarDocumentosDir','postulante'),
('F1','P6','P7','P','EnviarDocumentosCom','direccion'),
('F1','P7','--','C','CumpleRequisitos','comision'),
('F1','P8','--','F','NotificarPostulante','comision');


DROP TABLE alumno;

CREATE TABLE alumno(
    id INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(20),
    paterno VARCHAR(20),
    materno VARCHAR(20),
    matricula VARCHAR(10),
    email VARCHAR(20),
    PRIMARY KEY (id)
);

INSERT INTO alumno(nombre, paterno, materno, matricula, email) VALUES
('Gary','Tarquino','Hualper', '199524', 'gary@gmail.com'),
('Liz','Segales','Mendoza', '186525', 'liz@gmail.com'),
('Jhonathan','Díaz','Ortiz', '175523', 'diaz@gmail.com'),
('Moises','Silva','Choque', '299761', 'moi@gmail.com');