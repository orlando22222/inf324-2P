﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        int Rm, Gm, Bm;
        int pR, pG, pB;
        int Rmc, Gmc, Bmc, L = 10;

        //Boolean isTone = true;
        Boolean isSolid = false;

        List<List<string>> argb = new List<List<string>>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = string.Empty;
            openFileDialog1.Filter = "Archivos *.*|";
            openFileDialog1.ShowDialog();
            if (openFileDialog1.FileName != string.Empty)
            {
                bmp = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = bmp;
                pictureBox2.Image = bmp;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Color c = new Color();
            c = bmp.GetPixel(15, 15);
            textBox1.Text = c.R.ToString();
            textBox2.Text = c.R.ToString();
            textBox3.Text = c.R.ToString();
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            //TEXTURIZAR
            /*Bitmap bmp = new Bitmap(pictureBox1.Image);
            Color c = new Color();
            c = bmp.GetPixel(e.X, e.Y);
            Rm = c.R;
            Gm = c.G;
            Bm = c.B;
            Rmc = 0; Gmc = 0; Bmc = 0;
            textBox1.Text = c.R.ToString();
            textBox2.Text = c.G.ToString();
            textBox3.Text = c.B.ToString();
            for (int i = e.X - ((int)L / 2); i < e.X + ((int)L / 2); i++)
                for (int j = e.Y - ((int)L / 2); j < e.Y + ((int)L / 2); j++)
                {
                    c = bmp.GetPixel(i, j);
                    Rmc = Rmc + c.R; Gmc = Gmc + c.G; Bmc = Bmc + c.B;
                }
            Rmc = (int)Rmc / (L * L);
            Gmc = (int)Gmc / (L * L);
            Bmc = (int)Bmc / (L * L);
            textBox1.Text = textBox1.Text + " " + Rmc.ToString();
            textBox2.Text = textBox2.Text + " " + Gmc.ToString();
            textBox3.Text = textBox3.Text + " " + Bmc.ToString();*/

            List<string> zrgb = new List<string>();

            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Color c = new Color();
            pR = 0;
            pG = 0;
            pB = 0;

            for (int ki = e.X; ki < e.X + 10; ki++)
            {
                for (int kj = e.Y; kj < e.Y + 10; kj++)
                {
                    c = bmp.GetPixel(ki, kj);
                    pR = pR + c.R;
                    pG = pG + c.G;
                    pB = pB + c.B;
                }
            }
            pR = pR / 100;
            pG = pG / 100;
            pB = pB / 100;
            textBox1.Text = c.R.ToString();
            textBox2.Text = c.G.ToString();
            textBox3.Text = c.B.ToString();

            //cada click guardar lista [R,G,B] dentro de otra lista [[R,G,B],] cada 3 clicks se reinicia
            //mostrar contenido en textBox4
            if (argb.Count == 3)
            {
                argb.Clear();
            }

            zrgb.Add(c.R.ToString());
            zrgb.Add(c.G.ToString());
            zrgb.Add(c.B.ToString());
            argb.Add(zrgb);
            mostrar();
        }

        private void mostrar()
        {
            String txt = "";
            for (int i = 0; i < argb.Count; i++)
            {
                for (int j = 0; j < argb[i].Count; j++)
                {
                    if (j == 0)
                    {
                        txt += "[" + argb[i][j] + " , ";
                    }
                    else if (j == 1)
                    {
                        txt += argb[i][j];
                    }
                    else if (j == 2)
                    {
                        txt += " , " + argb[i][j] + "] ";
                    }

                }
            }
            textBox4.Text = txt;
        }


        // RED TONE
        private void button3_Click(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    c = bmp.GetPixel(i, j);
                    bmpR.SetPixel(i, j, Color.FromArgb(c.R, 0, 0));
                }
                pictureBox2.Image = bmpR;
            }
        }

        // GREEN TONE
        private void button4_Click(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    c = bmp.GetPixel(i, j);
                    bmpR.SetPixel(i, j, Color.FromArgb(0, c.G, 0));
                }
                pictureBox2.Image = bmpR;
            }
        }

        // BLUE TONE
        private void button5_Click(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    c = bmp.GetPixel(i, j);
                    bmpR.SetPixel(i, j, Color.FromArgb(0, 0, c.B));
                }
                pictureBox2.Image = bmpR;
            }
        }

        // GRAY COLOR
        private void button6_Click(object sender, EventArgs e)
        {
            int g = 3;
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    c = bmp.GetPixel(i, j);
                    bmpR.SetPixel(i, j, Color.FromArgb(c.R / g, c.G / g, c.B / g));
                }
                pictureBox2.Image = bmpR;
            }
        }

        // TEXTURIZAR
        private void button7_Click(object sender, EventArgs e)
        {
            //PARA QUE SE MANTENGA pictureBox2.Image
            //PARA QUE REINICIE pictureBox1.Image
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Bitmap bmp2 = new Bitmap(bmp.Width, bmp.Height);
            Color c = new Color();

            int r1 = Convert.ToInt32(argb[0][0]);
            int g1 = Convert.ToInt32(argb[0][1]);
            int b1 = Convert.ToInt32(argb[0][2]);

            for (int i = 0; i < bmp.Width; i++)
                for (int j = 0; j < bmp.Height; j++)
                {
                    c = bmp.GetPixel(i, j);
                    if (((r1 - 10 < c.R) && (c.R < r1 + 10)) &&
                        ((g1 - 10 < c.G) && (c.G < g1 + 10)) &&
                        ((b1 - 10 < c.B) && (c.B < b1 + 10)))
                        bmp2.SetPixel(i, j, Color.Black);
                    else
                        bmp2.SetPixel(i, j, Color.FromArgb(c.R, c.G, c.B));
                }
            pictureBox2.Image = bmp2;
        }

        //10x10
        private void button8_Click(object sender, EventArgs e)
        {
            int mR = 0, mG = 0, mB = 0;
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);

            int r1 = Convert.ToInt32(argb[0][0]);
            int g1 = Convert.ToInt32(argb[0][1]);
            int b1 = Convert.ToInt32(argb[0][2]);

            for (int i = 0; i < bmp.Width - 10; i = i + 10)
            {
                for (int j = 0; j < bmp.Height - 10; j = j + 10)
                {
                    mR = 0;
                    mG = 0;
                    mB = 0;
                    for (int ki = i; ki < i + 10; ki++)
                    {
                        for (int kj = j; kj < j + 10; kj++)
                        {
                            c = bmp.GetPixel(ki, kj);
                            mR = mR + c.R;
                            mG = mG + c.G;
                            mB = mB + c.B;
                        }
                    }
                    mR = mR / 100;
                    mG = mG / 100;
                    mB = mB / 100;

                    c = bmp.GetPixel(i, j);
                    if (((r1 - L <= mR) && (mR <= r1 + L)) &&
                        ((g1 - L <= mG) && (mG <= g1 + L)) &&
                        ((b1 - L <= mB) && (mB <= b1 + L)))
                    {
                        for (int ki = i; ki < i + 10; ki++)
                            for (int kj = j; kj < j + 10; kj++)
                            {
                                //bmpR.SetPixel(ki, kj, Color.Fuchsia);
                                //bmpR.SetPixel(ki, kj, Color.FromArgb(c.R, 0, 0));
                                if (isSolid)
                                {
                                    bmpR.SetPixel(ki, kj, Color.Gold);
                                }
                                else
                                {
                                    bmpR.SetPixel(ki, kj, Color.FromArgb(c.R, c.G, c.B));
                                }

                            }
                    }
                    else
                    {

                        for (int ki = i; ki < i + 10; ki++)
                        {
                            for (int kj = j; kj < j + 10; kj++)
                            {
                                c = bmp.GetPixel(ki, kj);
                                bmpR.SetPixel(ki, kj, Color.FromArgb(c.R, c.G, c.B));
                            }
                        }
                    }

                }

            }
            pictureBox2.Image = bmpR;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        //cambio 3 texturas
        private void button9_Click(object sender, EventArgs e)
        {
            int mR = 0, mG = 0, mB = 0;
            Color c = new Color();
            Bitmap bmpR = new Bitmap(bmp.Width, bmp.Height);

            int r1 = Convert.ToInt32(argb[0][0]);
            int g1 = Convert.ToInt32(argb[0][1]);
            int b1 = Convert.ToInt32(argb[0][2]);

            int r2 = Convert.ToInt32(argb[1][0]);
            int g2 = Convert.ToInt32(argb[1][1]);
            int b2 = Convert.ToInt32(argb[1][2]);

            int r3 = Convert.ToInt32(argb[2][0]);
            int g3 = Convert.ToInt32(argb[2][1]);
            int b3 = Convert.ToInt32(argb[2][2]);


            for (int i = 0; i < bmp.Width - 10; i = i + 10)
            {
                for (int j = 0; j < bmp.Height - 10; j = j + 10)
                {
                    mR = 0;
                    mG = 0;
                    mB = 0;
                    for (int ki = i; ki < i + 10; ki++)
                    {
                        for (int kj = j; kj < j + 10; kj++)
                        {
                            c = bmp.GetPixel(ki, kj);
                            mR = mR + c.R;
                            mG = mG + c.G;
                            mB = mB + c.B;
                        }
                    }
                    mR = mR / 100;
                    mG = mG / 100;
                    mB = mB / 100;

                    c = bmp.GetPixel(i, j);
                    /*
                     if (((pR - 5 <= mR) && (mR <= pR + 5)) &&
                        ((pG - 5 <= mG) && (mG <= pG + 5)) &&
                        ((pB - 5 <= mB) && (mB <= pB + 5)))
                     */

                    if (((r1 - L <= mR) && (mR <= r1 + L)) &&
                        ((g1 - L <= mG) && (mG <= g1 + L)) &&
                        ((b1 - L <= mB) && (mB <= b1 + L)))
                    {
                        for (int ki = i; ki < i + 10; ki++)
                            for (int kj = j; kj < j + 10; kj++)
                            {

                                if (isSolid)
                                {
                                    bmpR.SetPixel(ki, kj, Color.Red);
                                }
                                else
                                {
                                    bmpR.SetPixel(ki, kj, Color.FromArgb(c.R, 0, 0));
                                }

                            }
                    }
                    else if (((r2 - L <= mR) && (mR <= r2 + L)) &&
                        ((g2 - L <= mG) && (mG <= g2 + L)) &&
                        ((b2 - L <= mB) && (mB <= b2 + L)))
                    {
                        for (int ki = i; ki < i + 10; ki++)
                            for (int kj = j; kj < j + 10; kj++)
                            {
                                if (isSolid)
                                {
                                    bmpR.SetPixel(ki, kj, Color.Green);
                                }
                                else
                                {
                                    bmpR.SetPixel(ki, kj, Color.FromArgb(0, c.G, 0));
                                }
                            }
                    }
                    else if (((r3 - L <= mR) && (mR <= r3 + L)) &&
                    ((g3 - L <= mG) && (mG <= g3 + L)) &&
                    ((b3 - L <= mB) && (mB <= b3 + L)))
                    {
                        for (int ki = i; ki < i + 10; ki++)
                            for (int kj = j; kj < j + 10; kj++)
                            {
                                if (isSolid)
                                {
                                    bmpR.SetPixel(ki, kj, Color.Blue);
                                }
                                else
                                {
                                    bmpR.SetPixel(ki, kj, Color.FromArgb(0, 0, c.B));
                                }
                            }
                    }
                    else
                    {

                        for (int ki = i; ki < i + 10; ki++)
                        {
                            for (int kj = j; kj < j + 10; kj++)
                            {
                                c = bmp.GetPixel(ki, kj);
                                bmpR.SetPixel(ki, kj, Color.FromArgb(c.R, c.G, c.B));
                            }
                        }
                    }

                }

            }
            pictureBox2.Image = bmpR;

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (isSolid) {
                isSolid = false;
            } else {
                isSolid = true;
            }
            
        }

    }
}
